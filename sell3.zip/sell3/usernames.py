#coding=utf-8
#author:u'王健'
#Date: 13-8-21
#Time: 下午8:28
__author__ = u'王健'


USERNAMES='u=nSI_iRcroMByplRNkQvKQERZyytPmW&p=B%40WDCCCTT7wKNW5XlvV1slp38YmuCV'