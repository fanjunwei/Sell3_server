/**
 * Created by PyCharm.
 * User: u'王健'
 * Date: 11-12-8
 * Time: 下午9:43
 * To change this template use File | Settings | File Templates.
 */
function cells_color(tr,num){
	var oColor='';
	if(num==1){
		oColor="#C5D7EF";
	}else{
	 	oColor="#ffffff"
	}
    tr.style.backgroundColor=oColor;
}
//     tr.bgColor=oColor;
